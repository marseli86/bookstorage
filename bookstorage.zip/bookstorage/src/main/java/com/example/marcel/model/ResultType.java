package com.example.marcel.model;


public enum ResultType {
    SUCCESS,
    INVALID,
    NOT_FOUND
}

