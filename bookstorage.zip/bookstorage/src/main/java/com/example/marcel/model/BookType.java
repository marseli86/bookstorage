package com.example.marcel.model;

public enum BookType {
    ANTIQUE,SCIENCE,OTHER
}
