package com.example.marcel.controller;


import com.example.marcel.model.Book;
import com.example.marcel.model.Result;
import com.example.marcel.service.BookService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookController {

    private final BookService service;


    public BookController(BookService service) {
        this.service = service;
    }

    @GetMapping("/search/{barcode}")
    public Book findByBarcode(@PathVariable String barcode) {
        return service.findByBarcode(barcode);
    }

    @GetMapping("/calculate/{barcode}")
    public Double calculateTotalPrice(@PathVariable String barcode) {
        return service.calculateTotalPrice(barcode);
    }

    @PostMapping
    public ResponseEntity<Object> add(@RequestBody Book book) {
        Result<Book> result = service.add(book);
        if (result.isSuccess()) {
            return new ResponseEntity<>(result.getPayload(), HttpStatus.CREATED);
        }
        return ErrorResponse.build(result);
    }

    @PutMapping("/{barcode}")
    public ResponseEntity<Object> update(@PathVariable String barcode, @RequestBody Book book) {
        if (!barcode.equals(book.getBarcode())) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }

        Result<Book> result = service.update(book);
        if (result.isSuccess()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        return ErrorResponse.build(result);
    }

    @GetMapping
    public List<Object> findStockByQuantity() {
        return service.findStockByQuantity();
    }
}
