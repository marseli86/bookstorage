package com.example.marcel.model;

import java.time.LocalDate;


public class Book {

    private int id;
    private String name;
    private String author;
    private String barcode;
    private int quantity;
    private double price_per_unit;
    private LocalDate release_year;
    private int science_index;
    private BookType bookType;

    public BookType getBookType() {
        return bookType;
    }

    public void setBookType(BookType bookType) {
        this.bookType = bookType;
    }

    public Book() {
    }

    public LocalDate getRelease_year() {
        return release_year;
    }

    public void setRelease_year(LocalDate release_year) {
        this.release_year = release_year;
    }

    public int getScience_index() {
        return science_index;
    }

    public void setScience_index(int science_index) {
        this.science_index = science_index;
    }

    public Book(int id, String name, String author, String barcode, int quantity, double price_per_unit, LocalDate release_year, int science_index) {
        this.id = id;
        this.name = name;
        this.author = author;
        this.barcode = barcode;
        this.quantity = quantity;
        this.price_per_unit = price_per_unit;
        this.release_year = release_year;
        this.science_index = science_index;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice_per_unit() {
        return price_per_unit;
    }

    public void setPrice_per_unit(double price_per_unit) {
        this.price_per_unit = price_per_unit;
    }
}
