package com.example.marcel.data.mapper;

import com.example.marcel.model.Book;
import com.example.marcel.model.BookType;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class BookMapper implements RowMapper<Book> {
    @Override
    public Book mapRow(ResultSet resultSet, int i) throws SQLException {
        Book book =  new Book();
        book.setId(resultSet.getInt("id"));
        book.setName(resultSet.getString("name"));
        book.setAuthor(resultSet.getString("author"));
        book.setBarcode(resultSet.getString("barcode"));
        book.setQuantity(resultSet.getInt("quantity"));
        book.setPrice_per_unit(resultSet.getDouble("price_per_unit"));
        book.setBookType(BookType.valueOf(resultSet.getString("book_type")));
        book.setRelease_year(resultSet.getDate("release_year").toLocalDate());
        book.setScience_index(resultSet.getInt("science_index"));
        return book;
    }
}
