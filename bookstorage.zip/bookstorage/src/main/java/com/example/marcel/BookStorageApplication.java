package com.example.marcel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookStorageApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookStorageApplication.class, args);
	}

}
