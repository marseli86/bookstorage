package com.example.marcel.model;

public class Validations {

    public static boolean isNullOrBlank(String value) {
        return value == null || value.isEmpty();
    }
}