package com.example.marcel.service;

import com.example.marcel.data.BookRepository;
import com.example.marcel.model.*;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

private final BookRepository repository;


    public BookService(BookRepository repository) {
        this.repository = repository;
    }

    public Book findByBarcode(String barcode) {
        return repository.findByBarcode(barcode);
    }

    public Double calculateTotalPrice(String barcode){
        return repository.calculateTotalPrice(barcode);
    }

    public Result<Book> add(Book book) {
        Result<Book> result = validate(book);
        if (!result.isSuccess()) {
            return result;
        }

        if (book.getId() != 0) {
            result.addMessage("book cannot be set for `add` operation", ResultType.INVALID);
            return result;
        }

        book = repository.add(book);
        result.setPayload(book);
        return result;
    }

    public Result<Book> update(Book book) {

        Result<Book> result = validate(book);
        if (!result.isSuccess()) {
            return result;
        }

        if (book.getBarcode().isEmpty()) {
            result.addMessage("book cannot be set for `update` operation", ResultType.INVALID);
            return result;
        }

        if (!repository.update(book)) {
            String msg = String.format("book barcode: %s, not found", book.getBarcode());
            result.addMessage(msg, ResultType.NOT_FOUND);
        }


        return result;
    }

    public List<Object> findStockByQuantity() {
        return repository.findStockByQuantity();
    }

    private Result<Book> validate(Book book) {
        Result<Book> result = new Result<>();
        if (book == null) {
            result.addMessage("contact cannot be null", ResultType.INVALID);
            return result;
        }

        if (Validations.isNullOrBlank(book.getName())) {
            result.addMessage("name is required", ResultType.INVALID);
        }

        if (Validations.isNullOrBlank(book.getAuthor())) {
            result.addMessage("author is required", ResultType.INVALID);
        }

        if(book.getBookType()==null){
            result.addMessage("book type is required", ResultType.INVALID);
        }
        if(book.getBookType()== BookType.ANTIQUE && (book.getRelease_year()==null|| book.getRelease_year().getYear()>=1900 )){
            result.addMessage("release year is required and should be no more recent then 1900!", ResultType.INVALID);
        }

        if(book.getBookType()== BookType.SCIENCE && (book.getScience_index()<1||book.getScience_index()>10)){
            result.addMessage("science index is required and should be between 1 and 10", ResultType.INVALID);
        }

        return result;
    }
}
