package com.example.marcel.data;

import com.example.marcel.data.mapper.BookMapper;
import com.example.marcel.model.Book;
import com.example.marcel.model.BookType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;


import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

@Repository
public class BookJdbcRepositoryTemplate implements BookRepository {

    private final JdbcTemplate jdbcTemplate;

    public BookJdbcRepositoryTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }


    @Override
    public Book findByBarcode(String barcode) {
        final String sql = "SELECT id,name,author,barcode,quantity,price_per_unit,book_type,release_year,science_index "
                + "FROM book_storage   "
                + "where barcode = ?;";
        return jdbcTemplate.query(sql, new BookMapper(), barcode)
                .stream()
                .findFirst().orElse(null);
    }

    @Override
    public Book add(Book book) {
        final String sql = "insert into book_storage (name, author, barcode,quantity,price_per_unit,book_type,release_year,science_index) "
                + " values (?,?,?,?,?,?,?,?);";

        KeyHolder keyHolder = new GeneratedKeyHolder();
        int rowsAffected = jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, book.getName());
            ps.setString(2, book.getAuthor());
            ps.setString(3, book.getBarcode());
            ps.setInt(4,book.getQuantity());
            ps.setDouble(5,book.getPrice_per_unit());
            ps.setString(6, String.valueOf(book.getBookType()));
            ps.setDate(7, Date.valueOf(book.getRelease_year()));
            ps.setInt(8,book.getScience_index());

            return ps;
        }, keyHolder);

        if (rowsAffected <= 0) {
            return null;
        }

        book.setId(keyHolder.getKey().intValue());
        return book;
    }

    @Override
    public boolean update(Book book) {

            final String sql = "update book_storage set "
                    + "name = ?, "
                    + "author = ?, "
                    + "quantity = ?, "
                    + "price_per_unit = ?, "
                    + "book_type= ?, "
                    + "release_year = ?, "
                    + "science_index= ? "
                    + "where barcode = ?; ";

            return jdbcTemplate.update(sql,
                    book.getName(),
                    book.getAuthor(),
                    book.getQuantity(),
                    book.getPrice_per_unit(),
                    String.valueOf(book.getBookType()),
                    book.getRelease_year(),
                    book.getScience_index(),
                    book.getBarcode()) > 0;
        }


    @Override
    public List<Object> findStockByQuantity() {
        final String sql = "SELECT id,name,author,barcode,quantity,price_per_unit,book_type,release_year,science_index "
                + "FROM book_storage order BY quantity DESC; ";

        List<Book> books = jdbcTemplate.query(sql, new BookMapper());
        List<Object> temp= new ArrayList<>();

        for(Book book: books){
              temp.add(book.getBarcode());
              temp.add(book.getQuantity());
        }
        return temp;
    }

    @Override
    public Double calculateTotalPrice(String barcode) {
        final String sql = "SELECT id,name,author,barcode,quantity,price_per_unit,book_type,release_year,science_index "
                + "FROM book_storage   "
                + "where barcode = ?;";
        List<Book> books = jdbcTemplate.query(sql, new BookMapper(), barcode);
        double total_price= 0;

        for(Book book:books){
            if(book.getBookType()== BookType.ANTIQUE){
                int current_year = Calendar.getInstance().get(Calendar.YEAR);
                int release_year = book.getRelease_year().getYear();
                total_price +=book.getPrice_per_unit()*book.getQuantity()*(current_year-release_year)/10;

            }
            else if(book.getBookType()==BookType.SCIENCE){
                total_price = book.getPrice_per_unit()*book.getQuantity()*book.getScience_index();
            }
            else{
                total_price = book.getPrice_per_unit()*book.getQuantity();
            }

        }

       return total_price;

    }
}
