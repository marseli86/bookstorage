package com.example.marcel.data;

import com.example.marcel.model.Book;

import java.util.List;

public interface BookRepository {

    Book findByBarcode(String barcode);

    Book add(Book book);

    boolean update(Book book);

    List<Object> findStockByQuantity();

    Double calculateTotalPrice(String barcode);


}
