CREATE TABLE book_storage (
  id int NOT NULL AUTO_INCREMENT,
  name varchar(45) DEFAULT NULL,
  author varchar(45) DEFAULT NULL,
  barcode varchar(45) DEFAULT NULL,
  quantity int DEFAULT NULL,
  price_per_unit double DEFAULT NULL,
  book_type varchar(100) DEFAULT NULL,
  release_year date DEFAULT NULL,
  science_index int DEFAULT NULL,
  PRIMARY KEY (id)
);
