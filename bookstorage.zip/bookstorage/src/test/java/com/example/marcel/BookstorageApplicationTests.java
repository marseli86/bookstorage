package com.example.marcel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstorageApplicationTests {

	@Test
	void contextLoads() {
	}

}
